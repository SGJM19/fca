<template>
	<div id="body" style="height:100%;">
			<router-view ></router-view>
	</div>
</template>
<script>
	export default{
		data(){
			return{

			}
		}
	}
</script>
<style>
	
</style>