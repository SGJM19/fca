<template>
	<div id="error">
		<div class="text-xs-center">
			404 Error, page not found	
		</div>
		
	</div>

</template>
<script>
	export default{
		data(){
			return{

			}
		}
	}
</script>
<style>
	
</style>