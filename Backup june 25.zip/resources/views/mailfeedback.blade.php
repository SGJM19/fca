
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	#container{
		width:1000px;
	}
</style>
<body>
	<div id="container">
		<div>
			{{ nl2br($msg_head) }}
		</div>
		<br><br>
		<div>
			Remarks by {{$remarks_by}}
		</div>
	</div>
</body>
</html>