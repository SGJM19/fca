
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	#container{
		width:1000px;
	}
</style>
<body>
	<div id="container">
		<div>
			{{$msg_head}}
		</div>
		<br>
		<div>
			{{$msg_body}}
		</div>
		<br><br>
		<div><b>ADDITIONAL MESSAGE:</b></div>
		<div>
			"{{$msg_respond}}"
		</div>
	</div>
</body>
</html>