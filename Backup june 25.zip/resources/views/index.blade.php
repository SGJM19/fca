@extends('layout.app')

@section('title')
	Fraud Tool
@endsection


@section('content')
@endsection	